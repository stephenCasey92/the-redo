package WOTS;

public abstract class Item {


	
	int itemID;
	String boxSize;
	double price;
	String name;
	String description;
	double weightKG;
	boolean hasApplied;
	int quantityOfItem;
	
	public Item(int id, String box, double price, String name, String desc, double weight, boolean applied, int qoi)
	{
		this.itemID = id;
		this.boxSize = box;
		this.price = price;
		this.name = name;
		this.description = desc;
		this.weightKG = weight;
		this.hasApplied = applied;
		this.quantityOfItem = qoi;
	}

	public boolean isHasApplied() {
		return hasApplied;
	}

	public void setHasApplied(boolean hasApplied) {
		this.hasApplied = hasApplied;
	}

	public int getItemID() {
		return itemID;
	}

	public void setItemID(int itemID) {
		this.itemID = itemID;
	}

	public String getBoxSize() {
		return boxSize;
	}

	public void setBoxSize(String boxSize) {
		this.boxSize = boxSize;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getWeightKG() {
		return weightKG;
	}

	public void setWeightKG(double weightKG) {
		this.weightKG = weightKG;
	}
	
	
	
}
