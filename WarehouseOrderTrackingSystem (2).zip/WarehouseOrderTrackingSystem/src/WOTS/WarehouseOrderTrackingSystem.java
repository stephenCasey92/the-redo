package WOTS;

public class WarehouseOrderTrackingSystem {

	public static void main(String[] args) {
		
		// seeing if stuff is there
		
		OrderController orderController = new OrderController();
		Inventory inventory = new Inventory();

		
		
		
		
		
		
		

	}

}
