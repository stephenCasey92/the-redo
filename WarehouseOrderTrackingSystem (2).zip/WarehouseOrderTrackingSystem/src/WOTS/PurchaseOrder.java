package WOTS;
import java.util.ArrayList;


public class PurchaseOrder {
	int poID;
	String supplier;
	//boolean received;
	
	Status poStatus;
	
	ArrayList<OrderLine>ItemQuantity = new ArrayList<OrderLine>();
	
	public PurchaseOrder(int poID, String sup, Status poStatus){
		
		this.poID = poID;
		this.supplier = sup;
		this.poStatus= poStatus;
//		this.received = rec;
		
	}

	public int getPoID() {
		return poID;
	}

	public void setPoID(int poID) {
		this.poID = poID;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

//	public boolean isReceived() {
//		return received;
//	}

//	public void setReceived(boolean received) {
//		this.received = received;
//	}

	public ArrayList<OrderLine> getItemQuantity() {
		return ItemQuantity;
	}

	public void setItemQuantity(ArrayList<OrderLine> itemQuantity) {
		ItemQuantity = itemQuantity;
	}

	public Status getPoStatus() {
		return poStatus;
	}

	public void setPoStatus(Status poStatus) {
		this.poStatus = poStatus;
	}
	
	
}
