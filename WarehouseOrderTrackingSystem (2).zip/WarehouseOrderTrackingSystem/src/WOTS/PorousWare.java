package WOTS;

public interface PorousWare {
	
	public void applyPW();

}
