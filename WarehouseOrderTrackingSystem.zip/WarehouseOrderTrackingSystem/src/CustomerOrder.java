import java.util.ArrayList;


public class CustomerOrder {
	int orderID;
	boolean delivered;
	
	
	ArrayList<OrderLine>ItemQuantity = new ArrayList<OrderLine>();
	
	
	public CustomerOrder(int orderID, boolean del){
		
		this.orderID = orderID;
		this.delivered = del;
	}


	public int getOrderID() {
		return orderID;
	}


	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}


	public boolean isDelivered() {
		return delivered;
	}


	public void setDelivered(boolean delivered) {
		this.delivered = delivered;
	}


	public ArrayList<OrderLine> getItemQuantity() {
		return ItemQuantity;
	}


	public void setItemQuantity(ArrayList<OrderLine> itemQuantity) {
		ItemQuantity = itemQuantity;
	}
	

}
