
public class GardenTool extends Item {
	
	String function;
	boolean electrical;

	public GardenTool(int id, String box, double price, String name,
			String desc, double weight, boolean applied, String func, boolean elec) {
		super(id, box, price, name, desc, weight, applied);
		
		this.function = func;
		this.electrical = elec;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public boolean isElectrical() {
		return electrical;
	}

	public void setElectrical(boolean electrical) {
		this.electrical = electrical;
	}

}
