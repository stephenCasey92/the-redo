package WOTS;

public class OrderLine {

	int itemID;
	int quantity;
	public OrderLine(int itemID, int quantity) {

		this.itemID = itemID;
		this.quantity = quantity;
	}
	public int getItemID() {
		return itemID;
	}
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
