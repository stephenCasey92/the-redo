package WOTS;

public class Furniture extends Item{

	int seatingAmount;
	boolean hasPillows;
	
	
	public Furniture(int itemID, String boxSize, double price, String name, String description, double weight, boolean hasApplied,int seating, boolean pillows)
	{
		super(itemID, boxSize, price, name, description, weight, hasApplied);
		this.seatingAmount = seating;
		this.hasPillows = pillows;
		
	}

	public int getSeatingAmount() {
		return seatingAmount;
	}

	public void setSeatingAmount(int seatingAmount) {
		this.seatingAmount = seatingAmount;
	}

	public boolean isHasPillows() {
		return hasPillows;
	}

	public void setHasPillows(boolean hasPillows) {
		this.hasPillows = hasPillows;
	}
	
	
}
