package WOTS;

public class WarehouseOperative {
	int assignmentOrder;
	int employeeID;
	String name;


	public WarehouseOperative(int orderID, int employeeID, String name){
	
	this.assignmentOrder = orderID;
	this.employeeID = employeeID;
	this.name = name;
	
	}
	
	public void updateCustomerOrderStatus(boolean newStatus){
		
	}
	
	public void updatePurchaseOrderStatus(boolean newStatus){
		
	}

	public int getAssignmentOrder() {
		return assignmentOrder;
	}

	public void setAssignmentOrder(int assignmentOrder) {
		this.assignmentOrder = assignmentOrder;
	}

	public int getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
