/**
 * 
 */
package WOTS;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Test;

/**
 * @author Administrator
 *
 */
public class WOTSTests {

	@Test // Testing of the item class and it's subclasses
	public void itemObjTests() {

		// Furniture Tests
		Furniture furn = new Furniture(1,"50x50x50", 29.99, "Dave", "DaveObj", 35, false, 2, false);
		assertNotNull("ERROR: Furniture obj is Null",furn);



		// GardenTool - Tests
		GardenTool gt = new GardenTool(2, "25x25x25",35.99,"spade","gtObj",20,false,"digging",false);
		assertNotNull("ERROR: GardenTool obj is Null", gt);

		// Gnomes Tests
		Gnome gn = new Gnome(3,"15x15x15", 10.99, "ChristmasGnome", "Christmassy", 5.00, true, "Christmas", 0);
		assertNotNull("Error: Gnome obj is Null", gn);

		// Ornaments Tests
		Ornaments orn = new Ornaments(4, "90x50x80", 89.99, "Teapot", "tea", 1,"porcelain", "Lawn", true);
		assertNotNull("Error: Ornaments obj is Null", orn);





		Ornaments ornnament = new Ornaments(4, "90x50x80", 89.99, "Teapot", "tea", 1,"porcelain", "Lawn", true);
		assertNotSame("Error: Ornaments ", 99.99, orn.getPrice()); // Using assertSame here instead of assertEquals because assertEquals with doubles is deprecated
		ornnament.setPrice(99.99);
		assertSame("Error: Ornaments ", 99.99, orn.getPrice());


	}
	@Test
	public void warehouseOperativeTest(){ // testing the functions within the WarehouseOperative class

		// WarehouseOp - Test to see that the object is created and not null
		WarehouseOperative wo = new WarehouseOperative(0, 1, "Steve"); // will use this object throughout these tests (in this scope)
		assertNotNull("Error : WarehouseOperative is Null", wo);

		// WarehouseOp - updateCustomerOrderStatus function tests
		CustomerOrder co = new CustomerOrder(1, false);
		assertFalse("really messed up here", co.isDelivered());
		wo.updateCustomerOrderStatus(true);
		assertTrue("Customer Order status was not updated", co.isDelivered());
		wo.updateCustomerOrderStatus(false);
		assertFalse("Customer Order status was not updated", co.isDelivered());

		// WarehouseOp - updatePurchaseOrderStatus function tests
		PurchaseOrder po = new PurchaseOrder(1,"gnomes-r-us", false);
		assertFalse("really messed up here", po.isReceived());
		wo.updatePurchaseOrderStatus(true);
		assertTrue("Purchase Order status was not updated", po.isReceived());
		wo.updatePurchaseOrderStatus(false);
		assertFalse("Purchase Order status was not updated", po.isReceived());

		// Getters and Setters

	}
	@Test
	public void inventoryTests(){
		Inventory inv = new Inventory();
		

		// addItem(Item)
		assertTrue("not empty",inv.getInStockItems().isEmpty());
		GardenTool gt = new GardenTool(2, "25x25x25",35.99,"spade","gtObj",20,false,"digging",false);
		inv.addItem(gt); // adding a new item (gt) to the array of items in the Inventory class
		assertFalse("not emtpy",inv.getInStockItems().isEmpty());
		
		// addItem(ArrayList Item)
		Ornaments orn = new Ornaments(4, "90x50x80", 89.99, "Teapot", "tea", 1,"porcelain", "Lawn", true);
		Gnome gn = new Gnome(3,"15x15x15", 10.99, "ChristmasGnome", "Christmassy", 5.00, true, "Christmas", 0);
		GardenTool gtool = new GardenTool(5, "25x25x25",35.99,"another-spade","newgtObj",20,false,"digging",false);
		Furniture furn = new Furniture(1,"50x50x50", 29.99, "Dave", "DaveObj", 35, false, 2, false);
		
		ArrayList<Item> testArray = new ArrayList<Item>();
		
		testArray.add(orn); testArray.add(gn); testArray.add(gtool); testArray.add(furn);
		
		inv.addItem(testArray);
		assertEquals("above 5 items not added to list", 5, inv.getInStockItems().size());
		
		// pickOrderItems(arraylist)
		int sizeOfItemArray = inv.getInStockItems().size();
		ArrayList<Integer>removeArray = new ArrayList<Integer>();
		removeArray.add(4);removeArray.add(3);removeArray.add(2);
		inv.pickOrderItems(removeArray);
		assertEquals("Not Removed", sizeOfItemArray - 1, inv.getInStockItems().size());
		
		// pickOrderItems(int)
		sizeOfItemArray = inv.getInStockItems().size();
		inv.pickOrderItems(5);
		assertEquals("Not Removed", sizeOfItemArray - 1, inv.getInStockItems().size());
		
		
		// removeStockedItem(int)
		
		
		
		// removeStockedItem(Item)
	
		
	}
}

// assertEquals("ERROR ERROR ERROR",,);