package WOTS;

public class InterfaceHandler {

	public void primaryOptions()
	{
		int sChoice = 0;
		switch(sChoice)
		{
		case 1: // A list of orders can be printed and the user can select an order to view its information. 
			
			
			break;
		case 2: // The status of orders can be updated and the list of orders has a way of indicating which orders are being worked on. 

			
			break;
		case 3: // Stock deliveries orders can be added through the application. 

			
			break;
		case 4:
			break;
		case 5: 
			break;
		default:
			break;
		}
		
	}
	
	
}
