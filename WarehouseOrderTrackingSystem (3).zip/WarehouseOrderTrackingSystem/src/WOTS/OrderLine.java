package WOTS;

public class OrderLine {

	int itemID;
	int quantityOrdered;

	public OrderLine(int itemID, int quantity) {

		this.itemID = itemID;
		this.quantityOrdered = quantity;
	}

	public int getItemID() {
		return itemID;
	}

	public void setItemID(int itemID) {
		this.itemID = itemID;
	}

	public int getQuantity() {
		return quantityOrdered;
	}

	public void setQuantity(int quantity) {
		this.quantityOrdered = quantity;
	}

}
