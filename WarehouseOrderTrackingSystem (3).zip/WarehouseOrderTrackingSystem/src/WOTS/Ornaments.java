package WOTS;

public class Ornaments extends Item implements PorousWare {

	String material;
	String intendedLocation;
	//boolean hasApplied;
	
	public Ornaments(int id, String box, double price, String name,
			String desc, double weight,  String mat, int qui, String loc, boolean hasApplied) {
		super(id, box, price, name, desc, weight, hasApplied, qui);
		
		this.material = mat;
		this.intendedLocation = loc;
		
		
		// TODO Auto-generated constructor stub
	}
	
	
	public void applyPW(){
		
	}


	public String getMaterial() {
		return material;
	}


	public void setMaterial(String material) {
		this.material = material;
	}


	public String getIntendedLocation() {
		return intendedLocation;
	}


	public void setIntendedLocation(String intendedLocation) {
		this.intendedLocation = intendedLocation;
	}
	

	public void printer(){
		System.out.println("ID: "+ itemID + "\nName: " + name + "\nPrice: " + price + 
							"\nDescription: " + description + "\nHas PorousWare: " + hasApplied 
							+ "\nMaterial: " + material + "\nLocation at house: " + intendedLocation);	
}
}
