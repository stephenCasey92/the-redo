package WOTS;
import java.util.ArrayList;


public class Inventory {

	ArrayList<Item>inStockItems = new ArrayList <Item>();
	ArrayList<CustomerOrder>pendingCustomerOrders = new ArrayList<CustomerOrder>();
	
		
	
	public Inventory() {} // default anyway

	public void pickOrderItems(ArrayList<Integer>items){
		
		for(int i = 0; i<items.size(); i++)
		{
			for(int j = 0; j < inStockItems.size(); j++)
			{
				if(items.get(i) == inStockItems.get(j).getItemID())
				{
					inStockItems.remove(j);
					//break;
				}
			}			
		}		
	}
	
	public void pickOrderItems(int itemID){
		for (int i = 0; i<inStockItems.size(); i++){
			if(itemID == inStockItems.get(i).getItemID())
			{
				inStockItems.remove(i);
				break;
			}
		}
	}
	
//	public void removeStockedItem(int itemID){
//		
//		
//		
//		
//		/*
//		Item it = null; // ????????
//		for (int i = 0; i<inStockItems.size();i++){
//			if (itemID == inStockItems.get(i).getItemID()){
//				it = inStockItems.get(i); // possible redefinition issues?
//			}
//		}
//		if(it instanceof Gnome){
//			
//		}
//		else if(it instanceof GardenTool){
//			
//		} 
//		else if(it instanceof Furniture){
//			
//		} 
//		else if(it instanceof Ornaments)
//		{
//			
//		} else if(it == null)
//			System.out.println("No item :S");*/
//		
//	}
	
	public void removeStockedItem(Item item){
		
		for(int i = 0; i<inStockItems.size(); i++){
			if(item.getClass().equals(inStockItems.get(i).getClass())){
				inStockItems.remove(i);
			}
	
		}
	}
	
/*	public void removeStockedItem(ArrayList<Integer>itemID){
		
	}
	
	public void removeStockedItem(ArrayList<Item>Item){
	
	}*/
		
	public void addItem(Item item){
		inStockItems.add(item);
	}	
		
	public void addItem(ArrayList<Item> items){
		inStockItems.addAll(items);
	}

	public ArrayList<Item> getInStockItems() {
		return inStockItems;
	}

	public void setInStockItems(ArrayList<Item> inStockItems) {
		this.inStockItems = inStockItems;
	}

	public ArrayList<CustomerOrder> getPendingCustomerOrders() {
		return pendingCustomerOrders;
	}

	public void setPendingCustomerOrders(
			ArrayList<CustomerOrder> pendingCustomerOrders) {
		this.pendingCustomerOrders = pendingCustomerOrders;
	}		
	
	public void stockReplishmnet(PurchaseOrder pOrder){
		ArrayList<OrderLine> ol = pOrder.getItemQuantity();
		
		for(int i = 0; i < ol.size();i++){
			for(int j = 0; j < inStockItems.size(); j++){
				if(inStockItems.get(j).itemID == ol.get(i).itemID){
					inStockItems.get(j).setQuantityOfItem(ol.get(i).getQuantity() + inStockItems.get(j).getQuantityOfItem());
				}
			}
		}
	}
	
	
	
	
}
