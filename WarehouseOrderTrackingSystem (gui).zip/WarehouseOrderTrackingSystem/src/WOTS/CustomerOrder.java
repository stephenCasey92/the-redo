package WOTS;
import java.util.ArrayList;


public class CustomerOrder {
	int orderID;
//	boolean delivered;
//	boolean workingOnStatus;
	Status coStatus;
	ArrayList<OrderLine>ItemQuantity = new ArrayList<OrderLine>();
	Customer CustObj;
	
	public CustomerOrder(int orderID, Status coStatus, OrderLine ol, Customer CustObj){
		
		this.CustObj = CustObj;
		this.orderID = orderID;
		this.coStatus = coStatus;
		ItemQuantity.add(ol);
//		this.delivered = del;
//		this.workingOnStatus = wos;
	}
	public CustomerOrder(int orderID, Status coStatus, ArrayList<OrderLine> ol, Customer CustObj){
		
		this.CustObj = CustObj;
		this.orderID = orderID;
		this.coStatus = coStatus;
		ItemQuantity.addAll(ol);
//		this.delivered = del;
//		this.workingOnStatus = wos;
	}


//	public boolean isWorkingOnStatus() {
//		return workingOnStatus;
//  }


	public void setWorkingOnStatus(boolean workingOnStatus) {
//		this.workingOnStatus = workingOnStatus;
	}


	public int getOrderID() {
		return orderID;
	}


	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}


//	public boolean isDelivered() {
//		return delivered;
//	}


	public void setDelivered(boolean delivered) {
//		this.delivered = delivered;
	}


	public ArrayList<OrderLine> getItemQuantity() {
		return ItemQuantity;
	}


	public void setItemQuantity(ArrayList<OrderLine> itemQuantity) {
		ItemQuantity = itemQuantity;
	}


	public Status getCoStatus() {
		return coStatus;
	}


	public void setCoStatus(Status coStatus) {
		this.coStatus = coStatus;
	}
	public Customer getCustObj() {
		return CustObj;
	}
	public void setCustObj(Customer custObj) {
		CustObj = custObj;
	}
		
	

}
