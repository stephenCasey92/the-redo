package WOTS;

import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Objects;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class WarehouseOrderTrackingSystem extends JFrame{
	
	DefaultTableModel dtm;
	
	
	
	
	Container container; 
	JPanel mainMenu, customerOrdertab, purchaseOrdertab, Itemstab;
	JTabbedPane tPain;
	
	JSplitPane itemSplitPane;
	
	DefaultListModel itemModelList;
	JList<String> itemlist;
	
	JTable itemTable;
	
	JPanel itemPan1,itemPan2,itemPan3;
	
	JScrollPane itemTableScroll;
	JScrollPane itemListScroll;
	
	JButton mmButton, coButton, poButton, iButton;
		
	public WarehouseOrderTrackingSystem(){
		initUI();
		
	}
	
	public void initUI(){
		setTitle("Warehouse Order Tracking System");
		setSize(1600, 900);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		container = this.getContentPane();
		container.setLayout(new GridLayout(1,1));
		
		createComponents();
		container.add(tPain);
		
		
	}
	
	public void createComponents(){
		
		createMainMenuButtons();
		
		
	// panels
		
		mainMenu = new JPanel(new GridLayout(3,1));
		customerOrdertab = new JPanel();
		purchaseOrdertab = new JPanel();
		Itemstab = new JPanel();
		
		// item tab panels
		itemPan1 = new JPanel();
		itemPan2 = new JPanel();
		
		// building the item table
		String [] colNames = {"Item ID","Box Size","Price","Name", "Description", "Weight", "porousware", "Qauntity", "Material", 
				"Inteded Location", "Gnome Theme", "Gnome Batteried", "Tool Function", "Electrical Tool", "Seating Amount", "Pillows"};
		
		Object [][] data = {};
		
		
		//itemTable = new JTable(data, colNames);
		itemTable = new JTable();
		dtm = new DefaultTableModel(0,0);
		itemTableScroll = new JScrollPane(itemTable);
		itemTable.setFillsViewportHeight(true);
				
		dtm.setColumnIdentifiers(colNames);
		itemTable.setModel(dtm);
		
		
		// Item List (left side panel)
		
		itemModelList = new DefaultListModel();
		itemModelList.addElement("Jane Doe");
		itemModelList.addElement("John Smith");
		itemModelList.addElement("Kathy Green");
		
		//itemList = new
		
		String[] animals = {"1","2","3","4"};
		itemlist = new JList(itemModelList);
		
		itemTableScroll = new JScrollPane(itemTable);
		itemListScroll = new JScrollPane(itemlist);
		
		
		customerOrdertab.setBorder(BorderFactory.createLineBorder(Color.black));
		purchaseOrdertab.setBorder(BorderFactory.createLineBorder(Color.black));
		Itemstab.setBorder(BorderFactory.createLineBorder(Color.black));
	//	customerOrdertab.setBorder(BorderFactory.createLineBorder(Color.black));
		
		mainMenu.add(iButton);
		mainMenu.add(coButton);
		mainMenu.add(poButton);
		
		tPain = new JTabbedPane();
		tPain.setFont(new Font("Ariel",0,16));
		tPain.addTab("Main Menu", mainMenu);
		tPain.addTab("Customer Orders", customerOrdertab);
		tPain.addTab("Purcharse Orders", purchaseOrdertab);
		
		itemSplitPane = new JSplitPane();
		itemSplitPane.setDividerLocation(200);
		itemSplitPane.setLeftComponent(itemListScroll);
		itemSplitPane.setRightComponent(itemTableScroll);
		tPain.add("Items", itemSplitPane);
		
		
	}
	public void tableAddRow(Item it){
	
		
		String itID = Integer.toString(it.getItemID());
		String priceStr = Double.toString(it.getPrice());
		String weightStr = Double.toString(it.getWeightKG());
		String appliedStr = Boolean.toString(it.isHasApplied());
		String quiStr = Integer.toString(it.getQuantityOfItem());
		
		if(it instanceof GardenTool){
			String electrical = Boolean.toString(((GardenTool)it).isElectrical());
			
			
			dtm.addRow(new Object[]{itID, it.getBoxSize(), priceStr,it.getName(), 
					it.getDescription(), weightStr,
				appliedStr , quiStr, "", "","", "", ((GardenTool)it).getFunction(), electrical, "", ""});	
		}
		else if (it instanceof Gnome){
			String numBatteriesStr = Integer.toString(((Gnome)it).getNumberBatteries());
			
			dtm.addRow(new Object[]{itID, it.getBoxSize(), priceStr,it.getName(), 
					it.getDescription(), weightStr,
				appliedStr , quiStr, "", "", ((Gnome)it).getTheme(), numBatteriesStr, "", "", "", ""});
		}
		else if(it instanceof Ornaments){
			String material = ((Ornaments)it).getMaterial(); 
			String location = ((Ornaments)it).getIntendedLocation();
			
			dtm.addRow(new Object[]{itID, it.getBoxSize(), priceStr,it.getName(), 
					it.getDescription(), weightStr, appliedStr, quiStr, material, location, "", "","","", "", ""});
			
			
		}
		else if(it instanceof Furniture){
			String seating = Integer.toString(((Furniture)it).getSeatingAmount());
			String pillows = Boolean.toString(((Furniture)it).isHasPillows());
			
			dtm.addRow(new Object []{itID, it.getBoxSize(), priceStr,it.getName(), 
					it.getDescription(), weightStr,
				appliedStr , quiStr, "", "", "", "", "", "", seating, pillows });
		}
		
	}
	public void deleteTableRow(int ID){
		int rowID = 0;
		DefaultTableModel dtm2 = (DefaultTableModel) itemTable.getModel();
		int rowCount = dtm2.getRowCount(), colCount = dtm2.getColumnCount();
		Object[][] tableData = new Object[rowCount][colCount];
		
		Object rowFound = "";
		String rowFoundStr;
		
		/*for(int i = 0; i < rowCount; i++){
			if(dtm2.getValueAt(i, 0) == ID){ // ERRRO HERE. NEED TO CCHANGE THE STRING TO INT SOMEhow
			rowFound = dtm2.getValueAt(i, 0);
			break;
			}
		}*/
		rowFoundStr = (String) rowFound;
				
	}
	
	
	public void createMainMenuButtons()
	{
		coButton = new JButton("Customer Orders");
		poButton = new JButton("Purchase Orders");
		iButton = new JButton("Items");		
	}

	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable(){
		
		@Override
		public void run(){
			
			WarehouseOrderTrackingSystem wots =  new WarehouseOrderTrackingSystem();
			wots.setVisible(true);
			
			GardenTool fourCandles = new GardenTool(5, "25x63x42", 99.99, "Fork Handles", "Four candles, you know... Handles for forks.", 23, false, 4, "accessories", false);
			Gnome fisherMan = new Gnome(6, "30x35x40", 12.99, "Roddy", "Just a gnome, catching a phish", 2.00, true, 34, "action/adventure", 0);
			Furniture largeBench = new Furniture(2, "90x120x330", 65.99, "Big Ole Bench", "Bench that sits 5 medium sized folk", 70.00, false, 4, 5, true);
			Ornaments teaPot = new Ornaments(9, "120x145x120", 29.99, "Tea Pot", "An ornamental teapot", 1.00, "porcelain", 69, "Garden", true);

			
			wots.tableAddRow(fourCandles);
			wots.tableAddRow(fisherMan);
			wots.tableAddRow(largeBench);
			wots.tableAddRow(teaPot);
			
			wots.deleteTableRow(2);
			
		} 
	
	});
		
		
}
}