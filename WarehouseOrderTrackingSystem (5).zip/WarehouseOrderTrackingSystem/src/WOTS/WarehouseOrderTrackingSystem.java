package WOTS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class WarehouseOrderTrackingSystem {

	public static void main(String[] args) {

		// seeing if stuff is there

		OrderController orderController = new OrderController();
		Inventory inventory = new Inventory();


		Customer dave = new Customer(1, "David Davidson", "10, Platt View, South End, HP23 5BJ", "07856054331");
		Customer jeff = new Customer(2, "Jeffrey Jefferson", "234, Evergreen Terrace, Springfield, SP6 7LD", "07734598721");
		Customer betty = new Customer(3, "Betty Betts", "42 Wallaby Wall, Sydney, SY3 1EY", "0756752438");
		Customer craig = new Customer(4, "Craig David", "45 Private Drive, Oxford, OX8 2HP", "03263748272");
		
		orderController.customerDetails.add(dave);
		orderController.customerDetails.add(jeff);
		orderController.customerDetails.add(betty);
		orderController.customerDetails.add(craig);

		Furniture smallBench = new Furniture(1, "50x70x220", 22.99, "Wee bench", "Bench that sits 2 medium sized folk ", 35.5, false, 13, 2, false);
		Furniture largeBench = new Furniture(2, "90x120x330", 65.99, "Big Ole Bench", "Bench that sits 5 medium sized folk", 70.00, false, 4, 5, true);

		GardenTool shovel = new GardenTool(3, "20x36x155", 16.99, "Le Digger", " a shovel... for digging. prefect for that 6 foot hole in the middle of a forest....", 6.00, false, 40, "Digging", false);
		GardenTool lawnMower = new GardenTool(4, "124x160,200", 120.00, "Grass Shortener", "A big noisy machine that makes your lawn look pretty(ish)", 25.00, false, 6, "Mowing", true);
		GardenTool fourCandles = new GardenTool(5, "25x63x42", 99.99, "Fork Handles", "Four candles, you know... Handles for forks.", 23, false, 4, "accessories", false);

		Gnome fisherMan = new Gnome(6, "30x35x40", 12.99, "Roddy", "Just a gnome, catching a phish", 2.00, true, 34, "action/adventure", 0);
		Gnome nerdGnome = new Gnome(7, "42x44x66", 1.99, "Jack Gallacher", "A gnome that is sat at a computer looking very stressed and occassionally shouts JAAAAAAAAVA", 3.00, false, 23, "Nerd/Geek", 2);

		Ornaments bigChinaPot = new Ornaments(8, "120x145x120", 79.99, "Big Pot", "A BIG pot that sits in the garden with no use at all", 122.00, "porcelain", 54, "Patio", true);
		Ornaments teaPot = new Ornaments(9, "120x145x120", 29.99, "Tea Pot", "An ornamental teapot", 1.00, "porcelain", 69, "Garden", true);

		// Adds new order to purchase order
		Status newStat = Status.Delivered;
		PurchaseOrder pOrder1 = new PurchaseOrder(1, "Russells Furniture FUNHOUSE", newStat);
		pOrder1.addOrderLine(new OrderLine(1, 5));
		pOrder1.addOrderLine(new OrderLine(2, 5));

		//Adds 2nd order to purchase order
		PurchaseOrder pOrder2 = new PurchaseOrder(2, "Steves Gnome Emporium", Status.Delivered);
		pOrder2.addOrderLine(new OrderLine(6, 30));
		pOrder2.addOrderLine(new OrderLine(7, 12));

		ArrayList<Item> initItems = new ArrayList<Item>();
		initItems.addAll(Arrays.asList(smallBench, largeBench, shovel, lawnMower, fourCandles, fisherMan, nerdGnome, bigChinaPot, teaPot));
		inventory.addItem(initItems);


		ArrayList<OrderLine> orderLines = new ArrayList<OrderLine>();


		orderLines.add(new OrderLine(2,1));
		CustomerOrder custOrder = new CustomerOrder(1, Status.PickedItem, orderLines, dave); orderLines.clear();
		orderLines.add(new OrderLine(3,2));
		CustomerOrder custOrder2 = new CustomerOrder(2, Status.Delivered, orderLines, jeff); orderLines.clear();
		orderLines.add(new OrderLine(4,3));
		orderLines.add(new OrderLine(5,1));
		CustomerOrder custOrder3 = new CustomerOrder(3, Status.PendingStock, orderLines, betty); orderLines.clear();
		orderLines.add(new OrderLine(9,10));
		CustomerOrder custOrder4 = new CustomerOrder(4, Status.Submiited, orderLines, craig); orderLines.clear();

		orderController.addCustomerOrder(custOrder); orderController.addCustomerOrder(custOrder2);
		orderController.addCustomerOrder(custOrder3); orderController.addCustomerOrder(custOrder4);


		orderController.addPurchaseOrder(pOrder1); orderController.addPurchaseOrder(pOrder2);



		/*	for(int i = 0; i < orderController.getCustomerOrders().size(); i++)
		{
			System.out.println(orderController.getCustomerOrders().get(i).getOrderID() + " - " + orderController.getCustomerOrders().get(i).getItemQuantity().get(0).getItemID()
					+ " - " + orderController.getCustomerOrders().get(i).getItemQuantity().get(0).getQuantity());			
		}*/

		int sChoice = 99;
		Scanner scanner = new Scanner(System.in);
		boolean switchLoop = true;
		/*System.out.println("What do you want to do:\n"
				+ "1 = List orders and select an order to view its information\n2 = Update status of a customer order\n 0 = quit");
		sChoice = scanner.nextInt();*/
		while(switchLoop){
			switch(sChoice)
			{
			case 1: // A list of orders can be printed and the user can select an order to view its information. 
				for(int i = 0; i < orderController.getCustomerOrders().size(); i++)
				{
					System.out.println("Order ID: " + orderController.getCustomerOrders().get(i).getOrderID());

					for(int j = 0; j < orderController.getCustomerOrders().get(i).getItemQuantity().size(); j++){
						System.out.println(" - Item ID: " + orderController.getCustomerOrders().get(i).getItemQuantity().get(j).getItemID()
								+ "		- Item Quantity ordered: " + orderController.getCustomerOrders().get(i).getItemQuantity().get(j).getQuantity());
					}
				}
				scanner = new Scanner(System.in);
				System.out.println("\nChoose which order to view more info on (0 to quit): ");
				int choice = scanner.nextInt();

				ArrayList<OrderLine>Olines =  new ArrayList<OrderLine>();
				if (choice <= orderController.getCustomerOrders().size())
				{
					for (int i = 0; i < orderController.getCustomerOrders().size(); i++)
					{
						if (choice == orderController.getCustomerOrders().get(i).getOrderID())
						{
							System.out.println("\nOrder Status: " + orderController.getCustomerOrders().get(i).getCoStatus() + "\n_____________________");
							Olines = orderController.getCustomerOrders().get(i).getItemQuantity();
							break;
						}
					}	
					for (OrderLine ol : Olines){
						for(int i = 0; i < inventory.getInStockItems().size(); i++){
							if (ol.getItemID() == inventory.getInStockItems().get(i).getItemID())
							{
								inventory.getInStockItems().get(i).printer(); 
								System.out.println("_____________________");
								break;
							}					
						}
					}
				} sChoice = 99;
				break;
			case 2: // The status of orders can be updated and the list of orders has a way of indicating which orders are being worked on. 
				scanner = new Scanner(System.in);
				System.out.println("\nChoose which customer order to update the status of (0 to quit): ");
				int oChoice = scanner.nextInt();
				System.out.println("\nWhat is the new order status (type number for choice): \n"
						+ "1 = Submitted\n2 = Pending Stock\n3 = Picked items and sent for delivery\n4 = Delivered: ");
				int statusChoice = scanner.nextInt();

				if(statusChoice == 1){ // 1 = Submitted
					for (int i = 0; i < orderController.getCustomerOrders().size(); i++)
					{
						if (oChoice == orderController.getCustomerOrders().get(i).getOrderID())
						{
							orderController.getCustomerOrders().get(i).setCoStatus(Status.Submiited);
						}				
					}				
				}
				else if (statusChoice == 2){ // 2 = Pending Stock
					for (int i = 0; i < orderController.getCustomerOrders().size(); i++)
					{
						if (oChoice == orderController.getCustomerOrders().get(i).getOrderID())
						{
							orderController.getCustomerOrders().get(i).setCoStatus(Status.PendingStock);
						}				
					}	
				}
				else if (statusChoice == 3){ // 3 = Picked items
					for (int i = 0; i < orderController.getCustomerOrders().size(); i++)
					{
						if (oChoice == orderController.getCustomerOrders().get(i).getOrderID())
						{
							orderController.getCustomerOrders().get(i).setCoStatus(Status.PickedItem);
						}				
					}	
				}
				else if (statusChoice == 4){ // 4 = delivered
					for (int i = 0; i < orderController.getCustomerOrders().size(); i++)
					{
						if (oChoice == orderController.getCustomerOrders().get(i).getOrderID())
						{
							orderController.getCustomerOrders().get(i).setCoStatus(Status.Delivered);
						}				
					}	
				}
				else{System.out.println("Cmon m8 not an option.");}
				sChoice = 99;
				break;
			case 3: // Stock deliveries orders can be added through the application. 
				inventory.stockReplishmnet(pOrder1);  inventory.stockReplishmnet(pOrder2); //
				sChoice = 99;

				break;
			case 4: // updating order status so that other workers do not work on it

				System.out.println("Enter ID of the customer order to update status of: ");
				scanner = new Scanner(System.in);
				int orderStatChoice = scanner.nextInt();

				System.out.println("Enter number for the new Status: "
						+ "\n1 = Submitted \n2 = Pending Stock \n3 = Picked Item \n4 = Delivered:");
				int statChoice = scanner.nextInt();
				//				scanner = new Scanner(System.in);
				for(CustomerOrder co : orderController.getCustomerOrders())
				{
					if(co.getOrderID() == orderStatChoice){
						switch(statChoice)
						{
						case 1:	co.setCoStatus(Status.Submiited);
						
							break; 
						case 2: co.setCoStatus(Status.PendingStock);
						
							break;
						case 3: co.setCoStatus(Status.PickedItem);
						
							break;
						case 4: co.setCoStatus(Status.Delivered);
						
						    break;
						default: break;					
						}
						
						break;
					}
				}
				sChoice = 99;
				break;
			case 5: 
				for(Item i : inventory.getInStockItems())
					i.printer();
				sChoice = 99;
				break;
				
			case 6:
				System.out.println("First, enter the type item (number option): "
						+ "\n1 = Furniture\n2 = Ornament\n3 = Gnome\n4 = Garden Tool");
				scanner = new Scanner(System.in);
				int type = scanner.nextInt(); // user defined type of item
				if(type > 0 && type < 5)
					inventory.addItemHandler(type);
				
			case 7:
				
				break;
			case 0 :
				switchLoop = false;
				break;
			default:
				System.out.println("What do you want to do:\n"
						+ "1 = List orders and select an order to view its information\n2 = Update status of a customer order\n"
						+ "3 = Replenish stock from delivered Purchase Order\n4 = Update customer order status \n5 = View item list \n"
						+ "6 = Add an item to store \n0 = quit");
				sChoice = scanner.nextInt();
				break;
			}

		}
	}

}
