package WOTS;

public enum Status {
	Submiited, 
	AwaitingDelivery, 
	ReceivedStock, 
	PendingStock, 
	PickedItem,
	Delivered;
	

}
