package WOTS;
import java.util.ArrayList;


public class OrderController {
	
	// 	MAP
	
	ArrayList<CustomerOrder>customerOrders = new ArrayList<CustomerOrder>();
	ArrayList<PurchaseOrder>purchaseOrders = new ArrayList<PurchaseOrder>();
	ArrayList<Customer>customerDetails = new ArrayList<Customer>();

	public void addCustomerOrder(CustomerOrder order){
		if(order != null)
		{
			customerOrders.add(order);
		}
	
	}
	
	public void addPurchaseOrder(PurchaseOrder order){
		if (order != null)
		{
			purchaseOrders.add(order);
			
		}
	}
	
	

	public ArrayList<PurchaseOrder> getPurchaseOrders() {
		return purchaseOrders;
	}

	public void setPurchaseOrders(ArrayList<PurchaseOrder> purchaseOrders) {
		this.purchaseOrders = purchaseOrders;
	}

	public ArrayList<CustomerOrder> getCustomerOrders() {
		return customerOrders;
	}

	public void setCustomerOrders(ArrayList<CustomerOrder> customerOrders) {
		this.customerOrders = customerOrders;
	}


	

	public void updateCustomerOrderStatus(Status newStatus, int coid){
		for ( int i = 0; i<customerOrders.size();i++)
		{
			if(coid == customerOrders.get(i).getOrderID())
			{
				customerOrders.get(i).setCoStatus(newStatus);
			}
		}
	}
	
	public void updatePurchaseOrderStatus(Status newStatus, int poid){
		for (int i= 0; i<purchaseOrders.size();i++)
		{
			if (poid == purchaseOrders.get(i).getPoID())
			
				purchaseOrders.get(i).setPoStatus(newStatus);
			}
		}		
	}

	

