package WOTS;
import java.util.ArrayList;
import java.util.Scanner;


public class Inventory {

	ArrayList<Item>inStockItems = new ArrayList <Item>();
	ArrayList<CustomerOrder>pendingCustomerOrders = new ArrayList<CustomerOrder>();



	public Inventory() {} // default anyway

	public void pickOrderItems(ArrayList<Integer>items){

		for(int i = 0; i<items.size(); i++)
		{
			for(int j = 0; j < inStockItems.size(); j++)
			{
				if(items.get(i) == inStockItems.get(j).getItemID())
				{
					inStockItems.remove(j);
					//break;
				}
			}			
		}		
	}

	public void pickOrderItems(int itemID){
		for (int i = 0; i<inStockItems.size(); i++){
			if(itemID == inStockItems.get(i).getItemID())
			{
				inStockItems.remove(i);
				break;
			}
		}
	}

	public void pickOrderItemsQuantity(CustomerOrder co) // instead of just removing an item, this function will find the item and lower its quantity via customer order.
	{
		ArrayList<OrderLine> ol = co.getItemQuantity(); // get the array of items/quant from the customer order
		int subAmt = 0;
		
		for(int i = 0; i < ol.size(); i++)
		{
			subAmt = ol.get(i).getQuantity();
			for(int j = 0; j < this.getInStockItems().size(); j++)
			{
				if(ol.get(i).getItemID() == this.getInStockItems().get(j).getItemID())
				{
					this.getInStockItems().get(j).setQuantityOfItem(	this.getInStockItems().get(j).getQuantityOfItem() - subAmt		);
				}				
			}						
		}		
	}
	
	//	public void removeStockedItem(int itemID){
	//		
	//		
	//		
	//		
	//		/*
	//		Item it = null; // ????????
	//		for (int i = 0; i<inStockItems.size();i++){
	//			if (itemID == inStockItems.get(i).getItemID()){
	//				it = inStockItems.get(i); // possible redefinition issues?
	//			}
	//		}
	//		if(it instanceof Gnome){
	//			
	//		}
	//		else if(it instanceof GardenTool){
	//			
	//		} 
	//		else if(it instanceof Furniture){
	//			
	//		} 
	//		else if(it instanceof Ornaments)
	//		{
	//			
	//		} else if(it == null)
	//			System.out.println("No item :S");*/
	//		
	//	}

	public void removeStockedItem(Item item){ // removes an item from the items stock list via a item arguement

		for(int i = 0; i<inStockItems.size(); i++){
			if(item.getClass().equals(inStockItems.get(i).getClass())){
				inStockItems.remove(i); // STRONG POSSIBILITY OF ARRAY OUT OF BOUNDS
			}
		}
	}

	/*	public void removeStockedItem(ArrayList<Integer>itemID){

	}

	public void removeStockedItem(ArrayList<Item>Item){

	}*/

	public void addItem(Item item){
		inStockItems.add(item);
	}	

	public void addItem(ArrayList<Item> items){
		inStockItems.addAll(items);
	}

	public ArrayList<Item> getInStockItems() {
		return inStockItems;
	}

	public void setInStockItems(ArrayList<Item> inStockItems) {
		this.inStockItems = inStockItems;
	}

	public ArrayList<CustomerOrder> getPendingCustomerOrders() {
		return pendingCustomerOrders;
	}

	public void setPendingCustomerOrders(
			ArrayList<CustomerOrder> pendingCustomerOrders) {
		this.pendingCustomerOrders = pendingCustomerOrders;
	}		

	public void stockReplishmnet(PurchaseOrder pOrder){ // adds new stock to existing items via a purchase order
		ArrayList<OrderLine> ol = pOrder.getItemQuantity();

		for(int i = 0; i < ol.size();i++){
			for(int j = 0; j < inStockItems.size(); j++){
				if(inStockItems.get(j).itemID == ol.get(i).itemID){
					inStockItems.get(j).setQuantityOfItem(ol.get(i).getQuantity() + inStockItems.get(j).getQuantityOfItem());
				}
			}
		}
	}

	// This function adds a new item to the item store via user input of all its details.
	public void addItemHandler(int type){
		Scanner scanner = new Scanner(System.in);
		String boxSize = scanner.nextLine();
		double price = scanner.nextDouble();
		String name = scanner.nextLine();
		String description = scanner.nextLine();
		double weight = scanner.nextDouble();
		boolean hasApplied = scanner.nextBoolean();
		int qoi = scanner.nextInt(); scanner.close();

		switch (type){
		case 1:// Furniture
			scanner = new Scanner(System.in);
			int seating = scanner.nextInt();
			boolean pillows = scanner.nextBoolean();
			Furniture newFurn = new Furniture((this.getInStockItems().size())+1, boxSize, price, name, description, weight, hasApplied, qoi, seating, pillows);

			this.addItem(newFurn); scanner.close();
			break;
		case 2: // Ornament
			scanner = new Scanner (System.in);
			String mat = scanner.nextLine();
			String loc = scanner.nextLine();
			Ornaments newOrn = new Ornaments((this.getInStockItems().size())+1, boxSize, price, name, description, weight, mat, qoi, loc, hasApplied);				

			this.addItem(newOrn); scanner.close();
			break;
		case 3: // Gnome
			scanner = new Scanner (System.in);
			String theme = scanner.nextLine();
			int batts = scanner.nextInt();
			Gnome newGnome = new Gnome((this.getInStockItems().size())+1, boxSize, price, name, description, weight, hasApplied, qoi, theme, batts);

			this.addItem(newGnome); scanner.close();
			break;
		case 4: //GardenTool
			scanner = new Scanner(System.in);
			String function = scanner.nextLine(); 
			boolean electrical = scanner.nextBoolean();
			GardenTool newTool = new GardenTool((this.getInStockItems().size())+1, boxSize, price, name, description, weight, hasApplied, qoi, function, electrical);

			this.addItem(newTool); scanner.close();
			break;
		}
		scanner.close();
	}
	
	
}
