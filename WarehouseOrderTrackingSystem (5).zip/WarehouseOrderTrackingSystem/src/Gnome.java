
public class Gnome extends Item implements PorousWare{

	
	String theme;
	int numberBatteries;
	
	public Gnome(int id, String box, double price, String name, String desc,
			double weight, boolean applied, String theme, int batts) {
		super(id, box, price, name, desc, weight, applied);
		
		this.theme = theme;
		this.numberBatteries = batts;
		
		
		// TODO Auto-generated constructor stub
	}
	
	public void applyPW(){
		
	}

	public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}

	public int getNumberBatteries() {
		return numberBatteries;
	}

	public void setNumberBatteries(int numberBatteries) {
		this.numberBatteries = numberBatteries;
	}
	
	
}
