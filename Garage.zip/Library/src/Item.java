
public class Item {

	// Attributes
	int itemId;
	String datePublished;

	// Constructor
	public Item(int itemID, String datePublished) {
	this.itemId = itemID;
	this.datePublished= datePublished;
	
	}

	public int getItemID() {
		return itemId;
	}

	public void setItemID(int itemID) {
		this.itemId = itemId;
	}

	public String getDatePublished() {
		return datePublished;
	}

	public void setDatePublished(String datePublished) {
		this.datePublished = datePublished;
	}
	
		
		
		
		// Methods
}
