public class Person {

	// Attributes

	public String firstName;
	public String Surname;
	
	// Constructor

	public Person(String firstName, String Surname){
		this.firstName = firstName;
		this.Surname = Surname;
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSurname() {
		return Surname;
	}

	public void setSurname(String surname) {
		Surname = surname;
	}

	
	// Methods
}
