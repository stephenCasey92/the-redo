
public class Librarian extends Person{

	// Attributes
	public int employeeId;
	
	// Constructor
	
	public Librarian(String firstName, String Surname, int employeeId){
		super(firstName, Surname);
	}



	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
		
	}
		
			
			

		
		// Methods
		
	
	}
	

