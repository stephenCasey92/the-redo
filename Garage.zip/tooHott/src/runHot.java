
public class runHot {

	public static void main(String[] args) {
			tooHot myTest = new tooHot();
			boolean answer = myTest.tempCheck(0, true);
	}
}
