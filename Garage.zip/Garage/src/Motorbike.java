
public class Motorbike extends Vehicle{
	String bikeType;
	
	
public Motorbike(String make, String model, String reg, int vId,
			int numberOfSeats, String bike) {
		super(make, model, reg, vId, numberOfSeats);
		
		bikeType = bike;
	}




}


	
	

	


