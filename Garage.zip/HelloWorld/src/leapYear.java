
public class leapYear {

	public static void main(String[] args) {


	}

}
