import java.util.ArrayList;


public class OrderController {
	
	// 	MAP
	ArrayList<CustomerOrder>customerOrders = new ArrayList<CustomerOrder>();
	ArrayList<WarehouseOperative>warehouseOps = new ArrayList<WarehouseOperative>();

	public void checkOutOrder(CustomerOrder order){
		
	}
	
	public void removeAssignedOrder(CustomerOrder order){
		
	}

	public ArrayList<CustomerOrder> getCustomerOrders() {
		return customerOrders;
	}

	public void setCustomerOrders(ArrayList<CustomerOrder> customerOrders) {
		this.customerOrders = customerOrders;
	}

	public ArrayList<WarehouseOperative> getWarehouseOps() {
		return warehouseOps;
	}

	public void setWarehouseOps(ArrayList<WarehouseOperative> warehouseOps) {
		this.warehouseOps = warehouseOps;
	}
	
		
}
