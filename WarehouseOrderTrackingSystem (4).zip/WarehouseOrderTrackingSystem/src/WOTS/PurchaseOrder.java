package WOTS;
import java.util.ArrayList;


public class PurchaseOrder {
	int poID;
	String supplier;
	//boolean received;
	
	Status poStatus;
	
	ArrayList<OrderLine>itemQuantity = new ArrayList<OrderLine>(); // holds a list of the items they want, and the quantity they want in the object of the item (reuses the stock quantity int)
	
	public PurchaseOrder(int poID, String sup, Status poStatus){
		
		this.poID = poID;
		this.supplier = sup;
		this.poStatus= poStatus;
//		this.received = rec;
		
	}
	
	public void addOrderLine(OrderLine ol)
	{
		if(ol != null)
			itemQuantity.add(ol);		
	}
	
	public void addOrderLine(ArrayList<OrderLine> ol)
	{
		if(!ol.isEmpty())
			itemQuantity.addAll(ol);
	}
	
	
	
	///////////// GETTERS AND SETTERS
	
	public int getPoID() {
		return poID;
	}

	public void setPoID(int poID) {
		this.poID = poID;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

//	public boolean isReceived() {
//		return received;
//	}

//	public void setReceived(boolean received) {
//		this.received = received;
//	}

	public ArrayList<OrderLine> getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(ArrayList<OrderLine> itemQuantity) {
		itemQuantity = itemQuantity;
	}

	public Status getPoStatus() {
		return poStatus;
	}

	public void setPoStatus(Status poStatus) {
		this.poStatus = poStatus;
	}
	
	
}
