package WOTS;

import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class WarehouseOrderTrackingSystem extends JFrame{
	
	
	Container container; 
	JPanel mainMenu, customerOrdertab, purchaseOrdertab, Itemstab;
	JTabbedPane tPain;
	
	JButton mmButton, coButton, poButton, iButton;
		
	public WarehouseOrderTrackingSystem(){
		initUI();
		
	}
	
	public void initUI(){
		setTitle("Warehouse Order Tracking System");
		setSize(1600, 900);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		container = this.getContentPane();
		container.setLayout(new GridLayout(1,1));
		
		createComponents();
		container.add(tPain);
		
		
	}
	
	public void createComponents(){
		
		createMainMenuButtons();
		
		
	// panels
		
		mainMenu = new JPanel(new GridLayout(3,1));
		customerOrdertab = new JPanel();
		purchaseOrdertab = new JPanel();
		Itemstab = new JPanel();
		
		customerOrdertab.setBorder(BorderFactory.createLineBorder(Color.black));
		purchaseOrdertab.setBorder(BorderFactory.createLineBorder(Color.black));
		Itemstab.setBorder(BorderFactory.createLineBorder(Color.black));
	//	customerOrdertab.setBorder(BorderFactory.createLineBorder(Color.black));
		
		mainMenu.add(iButton);
		mainMenu.add(coButton);
		mainMenu.add(poButton);
		
		tPain = new JTabbedPane();
		tPain.setFont(new Font("Ariel",0,16));
		tPain.addTab("Main Menu", mainMenu);
		tPain.addTab("Customer Orders", customerOrdertab);
		tPain.addTab("Purcharse Orders", purchaseOrdertab);
		tPain.addTab("Item", Itemstab);
		
	}
	
	public void createMainMenuButtons()
	{
		coButton = new JButton("Customer Orders");
		poButton = new JButton("Purchase Orders");
		iButton = new JButton("Items");		
	}

	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable(){
		
		@Override
		public void run(){
			
			WarehouseOrderTrackingSystem wots =  new WarehouseOrderTrackingSystem();
			wots.setVisible(true);
		} 
		
	});

}
}